"""
Personal Notes Organizer - local web application.
Run: python main.py
The app opens in your default browser and stores data in data.json.
Only Python's standard library is required.
"""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import json
import threading
import webbrowser
import csv
import io

from storage import load_notes, save_notes, new_note_id
from check import validate_note, clean_note
from report import build_summary, export_markdown, export_csv

HOST = "127.0.0.1"
PORT = 8000
ROOT = Path(__file__).resolve().parent


class NotesHandler(SimpleHTTPRequestHandler):
    """Handles website files and the small JSON API used by the page."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length).decode("utf-8") if length else "{}"
        return json.loads(raw)

    def do_GET(self):
        path = urlparse(self.path).path

        if path == "/api/notes":
            notes = load_notes()
            query = parse_qs(urlparse(self.path).query)
            keyword = query.get("q", [""])[0].strip().lower()
            category = query.get("category", [""])[0].strip().lower()
            tag = query.get("tag", [""])[0].strip().lower()

            filtered = []
            for note in notes:
                searchable = " ".join([
                    note.get("title", ""), note.get("content", ""),
                    note.get("category", ""), " ".join(note.get("tags", []))
                ]).lower()
                if keyword and keyword not in searchable:
                    continue
                if category and category != "all" and note.get("category", "").lower() != category:
                    continue
                if tag and tag not in [t.lower() for t in note.get("tags", [])]:
                    continue
                filtered.append(note)
            filtered.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
            return self.send_json(filtered)

        if path == "/api/summary":
            return self.send_json(build_summary(load_notes()))

        if path == "/api/export/markdown":
            data = export_markdown(load_notes()).encode("utf-8")
            return self.send_download(data, "notes_report.md", "text/markdown; charset=utf-8")

        if path == "/api/export/csv":
            data = export_csv(load_notes()).encode("utf-8")
            return self.send_download(data, "notes_report.csv", "text/csv; charset=utf-8")

        if path == "/api/export/json":
            data = json.dumps(load_notes(), ensure_ascii=False, indent=2).encode("utf-8")
            return self.send_download(data, "notes_backup.json", "application/json")

        if path == "/" or path == "/index.html":
            self.path = "/index.html"
        return super().do_GET()

    def send_download(self, data, filename, content_type):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            payload = self.read_json()

            if path == "/api/notes":
                errors = validate_note(payload)
                if errors:
                    return self.send_json({"errors": errors}, 400)
                note = clean_note(payload)
                notes = load_notes()
                note["id"] = new_note_id(notes)
                notes.append(note)
                save_notes(notes)
                return self.send_json(note, 201)

            if path == "/api/import":
                # Import CSV text sent by the browser. Invalid rows are reported.
                csv_text = payload.get("csv", "")
                reader = csv.DictReader(io.StringIO(csv_text))
                notes = load_notes()
                added, errors = 0, []
                for row_number, row in enumerate(reader, start=2):
                    row_data = {
                        "title": row.get("title", ""),
                        "content": row.get("content", ""),
                        "category": row.get("category", "General") or "General",
                        "tags": row.get("tags", ""),
                        "due_date": row.get("due_date", "")
                    }
                    row_errors = validate_note(row_data)
                    if row_errors:
                        errors.append({"row": row_number, "errors": row_errors})
                        continue
                    note = clean_note(row_data)
                    note["id"] = new_note_id(notes)
                    notes.append(note)
                    added += 1
                save_notes(notes)
                return self.send_json({"added": added, "errors": errors})

            return self.send_json({"error": "Endpoint not found."}, 404)
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.send_json({"error": f"Invalid request: {exc}"}, 400)
        except Exception as exc:
            return self.send_json({"error": f"Server error: {exc}"}, 500)

    def do_PUT(self):
        path = urlparse(self.path).path
        try:
            payload = self.read_json()
            note_id = path.rsplit("/", 1)[-1]
            errors = validate_note(payload)
            if errors:
                return self.send_json({"errors": errors}, 400)

            notes = load_notes()
            for index, old_note in enumerate(notes):
                if str(old_note.get("id")) == note_id:
                    updated = clean_note(payload)
                    updated["id"] = old_note["id"]
                    updated["created_at"] = old_note.get("created_at", updated["created_at"])
                    notes[index] = updated
                    save_notes(notes)
                    return self.send_json(updated)
            return self.send_json({"error": "Note not found."}, 404)
        except Exception as exc:
            return self.send_json({"error": f"Could not update note: {exc}"}, 400)

    def do_DELETE(self):
        note_id = urlparse(self.path).path.rsplit("/", 1)[-1]
        notes = load_notes()
        remaining = [note for note in notes if str(note.get("id")) != note_id]
        if len(remaining) == len(notes):
            return self.send_json({"error": "Note not found."}, 404)
        save_notes(remaining)
        return self.send_json({"success": True})


def main():
    server = ThreadingHTTPServer((HOST, PORT), NotesHandler)
    url = f"http://{HOST}:{PORT}"
    print("=" * 58)
    print("  PERSONAL NOTES ORGANIZER")
    print("  Your notes. Your tags. Your files. All stored locally.")
    print("=" * 58)
    print(f"Website: {url}")
    print("Keep this terminal window open while using the website.")
    print("Press Ctrl+C to stop the application.")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\\nClosing Personal Notes Organizer...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
