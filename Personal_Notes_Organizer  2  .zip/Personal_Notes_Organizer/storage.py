"""Local JSON storage helpers."""
from pathlib import Path
import json
from datetime import datetime

DATA_FILE = Path(__file__).resolve().parent / "data.json"


def load_notes():
    """Load notes safely. Missing or damaged files start as an empty list."""
    if not DATA_FILE.exists():
        save_notes([])
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError("The JSON root must be a list.")
        # Ignore malformed records instead of crashing the whole application.
        return [item for item in data if isinstance(item, dict) and "id" in item]
    except (json.JSONDecodeError, OSError, ValueError):
        backup = DATA_FILE.with_suffix(".corrupt.json")
        try:
            DATA_FILE.replace(backup)
        except OSError:
            pass
        save_notes([])
        return []


def save_notes(notes):
    """Write safely using a temporary file, then replace the old file."""
    temp_file = DATA_FILE.with_suffix(".tmp")
    with temp_file.open("w", encoding="utf-8") as file:
        json.dump(notes, file, ensure_ascii=False, indent=2)
    temp_file.replace(DATA_FILE)


def new_note_id(notes):
    """Generate the next numeric note ID."""
    existing = [int(note.get("id", 0)) for note in notes
                if str(note.get("id", "")).isdigit()]
    return max(existing, default=0) + 1
