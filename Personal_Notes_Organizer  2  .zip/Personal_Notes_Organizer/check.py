"""Input validation and cleanup for Personal Notes Organizer."""
from datetime import datetime
import re

MAX_TITLE = 100
MAX_CONTENT = 5000
MAX_TAGS = 10
ALLOWED_CATEGORIES = {
    "General", "Study", "Work", "Personal", "Ideas", "Projects"
}


def validate_note(data):
    """Return a list of friendly validation errors; empty means valid."""
    errors = []
    title = str(data.get("title", "")).strip()
    content = str(data.get("content", "")).strip()
    category = str(data.get("category", "General")).strip()
    due_date = str(data.get("due_date", "")).strip()
    raw_tags = data.get("tags", "")

    if not title:
        errors.append("Title is required.")
    elif len(title) > MAX_TITLE:
        errors.append(f"Title must be {MAX_TITLE} characters or fewer.")

    if not content:
        errors.append("Note content is required.")
    elif len(content) > MAX_CONTENT:
        errors.append(f"Content must be {MAX_CONTENT} characters or fewer.")

    if category not in ALLOWED_CATEGORIES:
        errors.append("Choose a valid category.")

    tags = split_tags(raw_tags)
    if len(tags) > MAX_TAGS:
        errors.append(f"Use no more than {MAX_TAGS} tags.")
    for tag in tags:
        if len(tag) > 24:
            errors.append("Each tag must be 24 characters or fewer.")
            break
        if not re.fullmatch(r"[\w -]+", tag, flags=re.UNICODE):
            errors.append("Tags can contain letters, numbers, spaces, _ and - only.")
            break

    if due_date:
        try:
            datetime.strptime(due_date, "%Y-%m-%d")
        except ValueError:
            errors.append("Due date must be a valid date.")

    return errors


def split_tags(raw_tags):
    """Accept either a comma-separated string or a list of tags."""
    if isinstance(raw_tags, list):
        parts = raw_tags
    else:
        parts = str(raw_tags or "").split(",")
    result, seen = [], set()
    for item in parts:
        tag = str(item).strip().lstrip("#")
        if tag and tag.lower() not in seen:
            result.append(tag)
            seen.add(tag.lower())
    return result


def clean_note(data):
    """Normalize valid input and add timestamps."""
    now = datetime.now().isoformat(timespec="seconds")
    return {
        "title": str(data.get("title", "")).strip(),
        "content": str(data.get("content", "")).strip(),
        "category": str(data.get("category", "General")).strip(),
        "tags": split_tags(data.get("tags", "")),
        "due_date": str(data.get("due_date", "")).strip(),
        "created_at": data.get("created_at", now),
        "updated_at": now
    }
