"""Summary calculations and report exporters."""
import csv
import io
from collections import Counter
from datetime import date


def build_summary(notes):
    """Calculate dashboard numbers from the supplied notes."""
    today = date.today().isoformat()
    categories = Counter(note.get("category", "General") for note in notes)
    tagged = sum(1 for note in notes if note.get("tags"))
    due_notes = [note for note in notes if note.get("due_date")]
    overdue = [
        note for note in due_notes
        if note["due_date"] < today
    ]
    upcoming = [
        note for note in due_notes
        if today <= note["due_date"]
    ]
    return {
        "total": len(notes),
        "tagged": tagged,
        "without_tags": len(notes) - tagged,
        "categories": dict(categories),
        "overdue": len(overdue),
        "upcoming": len(upcoming),
        "latest": sorted(
            notes, key=lambda item: item.get("updated_at", ""), reverse=True
        )[:5]
    }


def export_markdown(notes):
    summary = build_summary(notes)
    lines = [
        "# Personal Notes Organizer — Report",
        "",
        f"- Generated: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"- Total notes: {summary['total']}",
        f"- Notes with tags: {summary['tagged']}",
        f"- Overdue notes: {summary['overdue']}",
        "",
        "## Notes",
        ""
    ]
    for note in notes:
        tags = ", ".join(note.get("tags", [])) or "No tags"
        lines.extend([
            f"### {note.get('title', 'Untitled')}",
            f"- Category: {note.get('category', 'General')}",
            f"- Tags: {tags}",
            f"- Due date: {note.get('due_date') or 'Not set'}",
            "",
            note.get("content", ""),
            ""
        ])
    return "\n".join(lines)


def export_csv(notes):
    output = io.StringIO()
    fields = ["id", "title", "content", "category", "tags", "due_date",
              "created_at", "updated_at"]
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for note in notes:
        row = dict(note)
        row["tags"] = ", ".join(note.get("tags", []))
        writer.writerow({key: row.get(key, "") for key in fields})
    return output.getvalue()
