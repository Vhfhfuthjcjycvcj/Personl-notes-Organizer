# Personal Notes Organizer

A beginner-friendly notes organizer built with Python's standard library. It opens as a website in your browser, while all notes remain saved locally in `data.json`.

## Requirements
- Python 3.8 or newer
- No external packages and no internet connection required

## Run the project

1. Extract the ZIP file.
2. Open the extracted `Personal_Notes_Organizer` folder.
3. Open Command Prompt / Terminal in that folder.
4. Run:

   ```bash
   python main.py
   ```

5. Your browser opens at `http://127.0.0.1:8000`.
6. Keep the terminal window open while using the website. Press `Ctrl+C` in the terminal to stop it.

On some Windows computers, use `py main.py` if `python main.py` does not work.

## Project files

| File | Purpose |
|---|---|
| `main.py` | Starts the local web server, opens the browser and handles website requests |
| `check.py` | Validates titles, content, categories, tags and due dates |
| `storage.py` | Loads and saves notes safely in JSON |
| `report.py` | Calculates dashboard summaries and creates Markdown/CSV reports |
| `index.html` | Website layout, styling and browser-side interactions |
| `data.json` | Sample notes; new and edited notes are saved here |

## Features
- Add, edit and delete notes
- Search by title, content, category or tags
- Filter by category
- Add up to 10 tags to each note
- Optional due dates with overdue/upcoming summary counts
- Automatic local JSON saving
- Export Markdown, CSV and JSON backup
- Import CSV with row-by-row validation
- 40 sample notes for a quick project demonstration
- Handles missing or damaged JSON storage by creating a fresh data file (damaged data is kept as `data.corrupt.json` when possible)

## CSV import format

The first row must contain these column names:

```csv
title,content,category,tags,due_date
Python revision,Review loops and functions,Study,"python, exam",2026-12-01
```

## How the project works

1. The browser loads `index.html`.
2. JavaScript sends requests to the Python server in `main.py`.
3. `check.py` validates every new or edited note.
4. `storage.py` saves valid notes into `data.json`.
5. `report.py` calculates summary numbers and prepares exports.

The app listens only on `127.0.0.1`, so it is intended for use on your own computer, not as a public website.
